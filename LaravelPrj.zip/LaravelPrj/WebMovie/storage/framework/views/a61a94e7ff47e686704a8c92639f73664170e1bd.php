 <?php $__env->startSection('content'); ?>
<div class="container" style="margin-left:-40px;width:-webkit-fill-available"
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table table-dark table-responsive" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tên phim</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Tên chính thức</th>
                        <th scope="col">Image</th>
                        <th scope="col">Poster Image</th>
                        <th scope="col">Năm</th>
                        <th scope="col">Quản lý</th>



                        <!-- <th scope="col">Số tập</th>
                        <th scope="col">Loại phim</th>
                        <th scope="col">Thể loại</th>
                        <th scope="col">Quốc gia</th>
                        <th scope="col">Hot</th>
                        <th scope="col">Độ phân giải</th>
                        <th scope="col">Loại phụ đề</th>
                        <th scope="col">Ngày tạo</th>
                        <th scope="col">Ngày cập nhật</th>
                        <th scope="col">Thời lượng</th>
                        <th scope="col">Status</th>
                        <th scope="col">Manage</th> -->

                    </tr>
                </thead>

                <tbody >
                    <?php $__currentLoopData = $resp['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $exists = \App\Models\Movie::where('slug', $res['slug'])->exists();
                    ?>
                    <?php if(!$exists): ?>
                        <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td scope="row"><?php echo e($res['name']); ?></td>
                            <td scope="row"><?php echo e($res['slug']); ?></td>
                            <td scope="row"><?php echo e($res['origin_name']); ?></td>
                            <td>
                                <img width="100" height="100" src="<?php echo e($resp['pathImage'].$res['thumb_url']); ?>">
                            </td>
                            <td>
                                <img width="100" height="100" src="<?php echo e($resp['pathImage'].$res['poster_url']); ?>">
                            </td>
                            <td scope="row"><?php echo e($res['year']); ?></td>

                            <td>
                                <a href="<?php echo e(route('leech-Detail',$res['slug'])); ?>" class="btn btn-primary" >Chi tiết phim </a>

                                <?php
                                    $movie = \App\Models\Movie::where('slug',$res['slug'])->first();
                                ?>
                                <?php if(!$movie): ?>
                                    <a href="<?php echo e(route('leech-store',$res['slug'])); ?>" class="btn btn-success" >Lưu phim </a>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/leech/index.blade.php ENDPATH**/ ?>