 <?php $__env->startSection('content'); ?>
<div class="container" style="width:-webkit-fill-available">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table table-dark" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Status</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Manage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key); ?></th>
                        <td><?php echo e($cate->title); ?></td>
                        <td><?php echo e($cate->description); ?></td>
                        <td>
                            <?php if($cate->status == 1): ?>
                                'Hiển thị'
                            <?php else: ?>
                                'Không hiển thị'
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($cate->slug); ?></td>
                        <td>
                        <?php echo Form::open(['route' => ['genre.destroy',$cate->id],
                                        'method'=>'DELETE',
                                        'onsubmit'=>'return confirm("Ngon thì xóa đi?")'
                                        ]); ?>

                                    <?php echo Form::submit('Xóa!',['class'=>'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                        <a href="<?php echo e(route('genre.edit',$cate->id)); ?>" class="btn btn-warning">Sửa</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/genre/index.blade.php ENDPATH**/ ?>