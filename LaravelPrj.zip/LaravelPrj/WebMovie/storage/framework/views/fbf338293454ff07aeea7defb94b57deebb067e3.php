<?php $__env->startSection('content'); ?>
<div class="container" style="margin-left:-40px;width:-webkit-fill-available">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table table-dark table-responsive" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tập</th>
                        <th scope="col">Link phim</th>
                        <th scope="col">Thêm</th>
                    </tr>
                </thead>
                <tbody >
                    <?php $__currentLoopData = $resp['episodes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $episode['server_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->parent->iteration); ?></th>
                                <td scope="row"><?php echo e($data['name']); ?></td>
                                <td scope="row"><?php echo e($data['link_embed']); ?></td>
                                <td scope="row">
                                    <a href="<?php echo e(route('leech-episodeAdd', [
                                            'slug' => $resp['movie']['slug']
                                        ])); ?>" class="btn btn-success">Thêm</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/leech/episode.blade.php ENDPATH**/ ?>