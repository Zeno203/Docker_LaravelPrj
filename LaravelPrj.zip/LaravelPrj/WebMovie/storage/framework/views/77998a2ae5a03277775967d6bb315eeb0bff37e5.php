<?php $__env->startSection('content'); ?>
<div class="row container" id="wrapper">
         <div class="halim-panel-filter">
            <div class="panel-heading">
               <div class="row">
                  <div class="col-xs-6">
                     <div class="yoast_breadcrumb hidden-xs"><span><span><a href="<?php echo e(route('category',$movie->category->slug)); ?>"><?php echo e($movie->category->title); ?></a> » <span><a href="<?php echo e(route('genre',$movie->genre->slug)); ?>"><?php echo e($movie->genre->title); ?></a> » <span class="breadcrumb_last" aria-current="page"><?php echo e($movie->title); ?></span></span></span></span></div>
                  </div>
               </div>
            </div>
            <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
               <div class="ajax"></div>
            </div>
         </div>
         <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
            <section id="content" class="test">
               <div class="clearfix wrap-content">
               <iframe style="height:450px;width:100%;margin-top:14px;border:0px" frameborder="0"  scrolling="0" allowfullscreen src="<?php echo e($episode->linkphim); ?>" ></iframe>
                  <div class="collapse" id="moretool">
                     <ul class="nav nav-pills x-nav-justified">
                        <li class="fb-like" data-href="" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></li>
                        <div class="fb-save" data-uri="" data-size="small"></div>
                     </ul>
                  </div>

                  <div class="clearfix"></div>
                  <div class="clearfix"></div>
                  <div class="title-block">
                     <a href="javascript:;" data-toggle="tooltip" title="Add to bookmark">
                        <div id="bookmark" class="bookmark-img-animation primary_ribbon" data-id="37976">
                           <div class="halim-pulse-ring"></div>
                        </div>
                     </a>
                     <div class="title-wrapper-xem full">
                        <h5 class="entry-title"><a href="" title="<?php echo e($movie->title); ?>" class="tl"><?php echo e($movie->title); ?></a></h5>
                     </div>
                  </div>
                  <div class="entry-content htmlwrap clearfix collapse" id="expand-post-content">
                     <article id="post-37976" class="item-content post-37976"></article>
                  </div>
                  <div class="clearfix"></div>
                  <div class="text-center">
                     <div id="halim-ajax-list-server"></div>
                  </div>
                  <div id="halim-list-server">
                     <ul class="nav nav-tabs" role="tablist">
                        <?php if($movie->resolution == 0): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i>
                           HD</a></li>
                           <?php elseif($movie->resolution == 1): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i>
                           SD</a></li>
                           <?php elseif($movie->resolution == 2): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i>
                           HDCam</a></li>
                           <?php elseif($movie->resolution == 3): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i>
                           FullHD</a></li>
                        <?php endif; ?>
                     </ul>

                     <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active server-1" id="server-0">
                           <div class="halim-server">
                              <ul class="halim-list-eps">
                                <?php $__currentLoopData = $movie->episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sotap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(url('xem-phim/'.$movie->slug.'/tap-'.$sotap->episode)); ?>">
                                    <li class="halim-episode"><span class="halim-btn halim-btn-2 <?php echo e($tapphim==$sotap->episode ? 'active' : ''); ?> halim-info-1-1 box-shadow" data-post-id="37976" data-server="1" data-episode="<?php echo e($sotap->episode); ?>" data-position="first" data-embed="0" data-title="Xem phim <?php echo e($movie->title); ?> - Tập<?php echo e($sotap->episode); ?> " data-h1="Phim <?php echo e($movie->title); ?> - Tập<?php echo e($sotap->episode); ?> "><?php echo e($sotap->episode); ?></span></li>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </ul>
                              <div class="clearfix"></div>
                           </div>
                        </div>
                     </div>

                  </div>
                  <div class="clearfix"></div>
                  <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Tags</span></h2>
                     </div>
                     <div class="entry-content htmlwrap clearfix">
                        <div class="video-item halim-entry-box">
                           <article id="post-38424" class="item-content">
                            <?php if($movie->tags!=NULL): ?>
                                <?php
                                    $tags = array();
                                    $tags = explode(',',$movie->tags);
                                ?>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(url('tag/'.$tag)); ?>"><?php echo e($tag); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php echo e($movie->title); ?>

                            <?php endif; ?>

                           </article>
                        </div>
                     </div>
            </section>

            <section class="related-movies">
            <div id="halim_related_movies-2xx" class="wrap-slider">
            <div class="section-bar clearfix">
            <h3 class="section-title"><span>CÓ THỂ BẠN MUỐN XEM</span></h3>
            </div>
            <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="thumb grid-item post-38498">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('movie',$mov->slug)); ?>"" title="<?php echo e($mov->title); ?>">
                              <figure>
                                    <?php if(isset($mov->image) && !empty($mov->image)): ?>
                                        <?php if(preg_match("/^http/", $mov->image)): ?>
                                            <img class="lazy img-responsive" src="<?php echo e($mov->image); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>">
                                        <?php else: ?>
                                            <img class="lazy img-responsive" src="<?php echo e(asset('public/upload/movie/'.$mov->image)); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <img class="lazy img-responsive" src="<?php echo e(asset('path_to_default_image.png')); ?>" alt="Default Image" title="Default Image">
                                    <?php endif; ?>
                                </figure>                              <span class="status">
                                    <?php if($mov->resolution == 0): ?>
                                            HD
                                    <?php elseif($mov->resolution == 1): ?>
                                            SD
                                    <?php elseif($mov->resolution == 2): ?>
                                            HDCam
                                    <?php elseif($mov->resolution == 3): ?>
                                            FullHD
                                    <?php endif; ?>
                              </span>
                              <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>
                                    <?php if($mov->phude == 0): ?>
                                        Vietsub
                                    <?php elseif($mov->phude == 1): ?>
                                        Thuyết minh
                                    <?php endif; ?>
                              </span>
                              <div class="icon_overlay"></div>
                              <div class="halim-post-title-box">
                                 <div class="halim-post-title ">
                                    <p class="entry-title"><?php echo e($mov->title); ?></p>
                                    <p class="original_title"><?php echo e($mov->title); ?></p>
                                 </div>
                              </div>
                           </a>
                        </div>
                     </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <script>
               jQuery(document).ready(function($) {
               var owl = $('#halim_related_movies-2');
               owl.owlCarousel({loop: true,margin: 4,autoplay: true,autoplayTimeout: 4000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
            </script>
            </div>
            </section>
         </main>
        <!-- <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-9" class="widget halim_tab_popular_videos-widget-3">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Top Views</span>
                     </div>
                  </div>

                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                         <?php $__currentLoopData = $phimhot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <article class="thumb grid-item post-38498" style="margin-bottom: 15px">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('movie',$hot->slug)); ?>" title="<?php echo e($hot->title); ?>">
                                 <img class="lazy img-responsive" src="<?php echo e(asset('public/upload/movie/'.$hot->image)); ?>" alt="<?php echo e(asset('public/upload/movie/'.$hot->image)); ?>" title="<?php echo e($hot->title); ?>">
                                 <span class="status">
                                    <?php if($hot->resolution == 0): ?>
                                            HD
                                    <?php elseif($hot->resolution == 1): ?>
                                            SD
                                    <?php elseif($hot->resolution == 2): ?>
                                            HDCam
                                    <?php elseif($hot->resolution == 3): ?>
                                            FullHD
                                    <?php endif; ?>
                                 </span>
                                 <span class="episode" style="margin-top:0px"><i class="fa fa-play" aria-hidden="true"></i>
                                    <?php if($hot->phude == 0): ?>
                                        Vietsub
                                    <?php elseif($hot->phude == 1): ?>
                                        Thuyết minh
                                    <?php endif; ?>
                                </span>
                                 <div class="icon_overlay"></div>
                                 <div class="halim-post-title-box">
                                    <div class="halim-post-title ">
                                       <p class="entry-title"><?php echo e($hot->slug); ?></p>
                                       <p class="original_title"><?php echo e($hot->title); ?></p>
                                    </div>
                                 </div>
                              </a>
                           </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                     </div>
                  </section>
                  <div class="clearfix"></div>
               </div>
            </aside> -->
            <?php echo $__env->make('pages.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/pages/watch.blade.php ENDPATH**/ ?>