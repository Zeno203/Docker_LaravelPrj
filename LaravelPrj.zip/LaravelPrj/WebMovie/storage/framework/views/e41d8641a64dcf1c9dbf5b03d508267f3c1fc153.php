 <?php $__env->startSection('content'); ?>
<div class="container" style="margin-left:-40px;width:-webkit-fill-available"
    <div class="row justify-content-center">
        <div class="col-md-12" style="overflow: auto;">
            <table class="table table-dark table-responsive" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tên phim</th>
                        <th scope="col">Số tập</th>
                        <th scope="col">Image</th>

                        <!-- <th scope="col">Slug</th> -->

                        <th scope="col">Loại phim</th>
                        <th scope="col">Thể loại</th>
                        <th scope="col">Quốc gia</th>
                        <th scope="col">Hot</th>
                        <th scope="col">Độ phân giải</th>
                        <th scope="col">Loại phụ đề</th>
<!--
                        <th scope="col">Ngày tạo</th>
                        <th scope="col">Ngày cập nhật</th> -->

                        <th scope="col">Năm</th>

                        <th scope="col">Thời lượng</th>

                        <th scope="col">Status</th>

                        <th scope="col">Manage</th>

                    </tr>
                </thead>
                <tbody >
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key); ?></th>
                        <!-- <?php echo($cate->id) ?> -->


                        <td><?php echo e($cate->title); ?></td>

                        <td>
                            <a href="<?php echo e(route('add-episode',[$cate->id])); ?>" class="btn btn-primary btn-xs">Thêm tập phim</a>
                            <a href="<?php echo e(route('leech-episode',[$cate->slug])); ?>" class="btn btn-success btn-xs" >Thêm phim API </a>
                            <?php echo e($cate->total_episodes); ?> tập
                        </td>

                        <!-- <td>
                            <img width="100%" height="80%" src="<?php echo e(asset('public/upload/movie/'.$cate->image)); ?>">
                        </td> -->

                        <td>
                            <?php if(isset($cate->image) && !empty($cate->image)): ?>
                                <?php if(preg_match("/^http/", $cate->image)): ?>

                                    <img width="100%" height="80%" src="<?php echo e($cate->image); ?>">
                                <?php else: ?>

                                    <img width="100%" height="80%" src="<?php echo e(asset('public/upload/movie/' . $cate->image)); ?>">
                                <?php endif; ?>
                            <?php else: ?>
                                <img width="100%" height="80%" src="<?php echo e(asset('path_to_default_image.png')); ?>">
                            <?php endif; ?>
                        </td>



                        <!-- <td><?php echo e($cate->slug); ?></td> -->

                        <td>

                            <?php echo Form::select('category_id', $category ,isset($cate) ? $cate->category->id:'',['class'=>'form-control category_choose','id'=>$cate->id]); ?>

                            <?php echo e($cate->category->title); ?>

                        </td>
                        <td>
                            <?php echo Form::select('genre_id', $genre ,isset($cate)? $cate->genre->id:'',['class'=>'form-control genre_choose','id'=>$cate->id]); ?>

                            <?php echo e($cate->genre->title); ?>

                        </td>
                        <td>
                            <?php echo Form::select('country_id', $country,isset($movie)? $cate->country->id:'',['class'=>'form-control country_choose','id'=>$cate->id]); ?>

                            <?php echo e($cate->country->title); ?>

                        </td>
                        <td>
                            <?php echo Form::select('phim_hot', ['1'=>'Phim hot','0'=>'Không hot'] ,isset($cate)? $cate->phim_hot:'',['class'=>'form-control hot_choose','id'=>$cate->id]); ?>


                            <?php if($cate->phim_hot == 1): ?>
                                'Phim hót hòn họt'
                            <?php else: ?>
                                'Phim không hot'
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cate->resolution == 0): ?>
                                'HD'
                            <?php elseif($cate->resolution == 1): ?>
                                'SD'
                            <?php elseif($cate->resolution == 2): ?>
                                'HDCam'
                            <?php elseif($cate->resolution == 3): ?>
                                'FullHD'
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cate->phude == 0): ?>
                                'Phụ đề'
                            <?php elseif($cate->phude == 1): ?>
                                'Thuyết minh'
                            <?php endif; ?>
                        </td>

                        <!-- <td>
                            <?php echo e($cate->ngaytao); ?>

                        </td>
                        <td>
                            <?php echo e($cate->ngaycapnhat); ?>

                        </td> -->

                        <td>
                            <?php echo Form::selectYear('year',2000,2023,$cate->year,['class'=>'select-year','id'=>$cate->id]); ?>

                        </td>

                        <td>
                            <?php echo e($cate->thoiluong); ?>

                        </td>

                        <td>

                            <?php if($cate->status == 1): ?>
                                'Hiển thị'
                            <?php else: ?>
                                'Không hiển thị'
                            <?php endif; ?>
                        </td>

                        <td>
                        <?php echo Form::open(['route' => ['movie.destroy',$cate->id],
                                        'method'=>'DELETE',
                                        'onsubmit'=>'return confirm("Ngon thì xóa đi?")'
                                        ]); ?>

                                    <?php echo Form::submit('Xóa!',['class'=>'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                        <a href="<?php echo e(route('movie.edit',$cate->id)); ?>" class="btn btn-warning">Sửa</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/movie/index.blade.php ENDPATH**/ ?>