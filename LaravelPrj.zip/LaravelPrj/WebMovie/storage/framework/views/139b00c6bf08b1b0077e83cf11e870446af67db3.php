 <?php $__env->startSection('content'); ?>
<div class="container" style="width:-webkit-fill-available">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <a href="<?php echo e(route('episode.index')); ?>" class="btn btn-family">Liệt kê danh sách tập phim</a>
                <div class="card-header">Quản lý tập phim</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(!isset($episode)): ?>
                    <?php echo Form::open(['route' => 'episode.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => ['episode.update',$episode->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>

                    <div class="form-group">
                        <?php echo Form::label('movie_id','Chọn phim',[]); ?>

                        <?php echo Form::select('movie_id',$list_movie ,isset($episode)? $episode->movie_id:'',['class'=>'form-control select-movie']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('linkphim','Nhập link phim',[]); ?>

                        <?php echo Form::text('linkphim' ,isset($episode)? $episode->linkphim:'',['class'=>'form-control']); ?>

                    </div>


                    <div class="form-group">
                        <?php echo Form::label('episode','Tập phim',[]); ?>

                        <?php echo Form::text('episode' ,isset($episode)? $episode->episode:'',['class'=>'form-control', 'id'=>'show_movie']); ?>


                        <!-- <?php echo Form::label('episode','Chọn tập phim',[]); ?>

                        <select name="episode" class="form-control" id="show_movie">

                        </select> -->
                    </div>



                    <div class="form-group">
                        <?php if(!isset($episode)): ?>
                            <?php echo Form::submit('Thêm tập phim!',['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                        <?php echo Form::submit('Cập nhật tập phim!',['class'=>'btn btn-success']); ?>

                        <?php endif; ?>
                    </div>
                    <?php echo Form::close(); ?>


                </div>

            </div>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/episode/form.blade.php ENDPATH**/ ?>