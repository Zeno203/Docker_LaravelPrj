<?php $__env->startSection('content'); ?>
<div class="row container" id="wrapper">
            <div class="halim-panel-filter">
               <div class="panel-heading">
                  <div class="row">
                     <div class="col-xs-6">
                        <div class="yoast_breadcrumb hidden-xs"><span><span><a href=""><?php echo e($country_slug->title); ?></a> » <span class="breadcrumb_last" aria-current="page">2020</span></span></span></div>
                     </div>
                  </div>
               </div>
               <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
                  <div class="ajax"></div>
               </div>
            </div>
            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
               <section>
                  <div class="section-bar clearfix">
                     <h1 class="section-title"><span><?php echo e($country_slug->title); ?></span></h1>
                  </div>
                  <div class="halim_box">
                  <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item post-37606">
                        <div class="halim-item">
                           <a class="halim-thumb" href="<?php echo e(route('movie',$mov->slug)); ?>">
                           <figure>
                                <?php if(isset($mov->image) && !empty($mov->image)): ?>
                                    <?php if(preg_match("/^http/", $mov->image)): ?>
                                        <img class="lazy img-responsive" src="<?php echo e($mov->image); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>">
                                    <?php else: ?>
                                        <img class="lazy img-responsive" src="<?php echo e(asset('public/upload/movie/'.$mov->image)); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img class="lazy img-responsive" src="<?php echo e(asset('path_to_default_image.png')); ?>" alt="Default Image" title="Default Image">
                                <?php endif; ?>
                            </figure>                              <span class="status">
                                    <?php if($mov->resolution == 0): ?>
                                            HD
                                    <?php elseif($mov->resolution == 1): ?>
                                            SD
                                    <?php elseif($mov->resolution == 2): ?>
                                            HDCam
                                    <?php elseif($mov->resolution == 3): ?>
                                            FullHD
                                    <?php endif; ?>
                              </span>
                              <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>
                                    <?php if($mov->phude == 0): ?>
                                        Vietsub
                                    <?php elseif($mov->phude == 1): ?>
                                        Thuyết minh
                                    <?php endif; ?>
                              </span>
                              <div class="icon_overlay"></div>
                              <div class="halim-post-title-box">
                                 <div class="halim-post-title ">
                                    <p class="entry-title"><?php echo e($mov->title); ?></p>
                                    <p class="original_title"><?php echo e($mov->title); ?></p>
                                 </div>
                              </div>
                           </a>
                        </div>
                     </article>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div class="clearfix"></div>
                  <div class="text-center">
                     <ul class='page-numbers'>
                        <li><span aria-current="page" class="page-numbers current">1</span></li>
                        <li><a class="page-numbers" href="">2</a></li>
                        <li><a class="page-numbers" href="">3</a></li>
                        <li><span class="page-numbers dots">&hellip;</span></li>
                        <li><a class="page-numbers" href="">55</a></li>
                        <li><a class="next page-numbers" href=""><i class="hl-down-open rotate-right"></i></a></li>
                     </ul>
                  </div>
               </section>
            </main>
            <?php echo $__env->make('pages.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/pages/country.blade.php ENDPATH**/ ?>