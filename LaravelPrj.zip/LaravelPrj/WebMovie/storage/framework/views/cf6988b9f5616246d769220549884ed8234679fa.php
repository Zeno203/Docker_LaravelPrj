 <?php $__env->startSection('content'); ?>
<div class="container" style="width:-webkit-fill-available">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <a href="<?php echo e(route('movie.index')); ?>" class="btn btn-family">Liệt kê phim</a>
                <div class="card-header">Quản lý phim</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(!isset($movie)): ?>
                    <?php echo Form::open(['route' => 'movie.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => ['movie.update',$movie->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>

                    <div class="form-group">
                        <?php echo Form::label('title','Title',[]); ?>

                        <?php echo Form::text('title',isset($movie)? $movie->title:'',['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('slug','Slug',[]); ?>

                        <?php echo Form::text('slug',isset($movie)? $movie->slug:'',['class'=>'form-control','placeholder'=>'Nhập vào dữ liệu','id'=>'convert_slug']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('description','Description',[]); ?>

                        <?php echo Form::textarea('description',isset($movie)? $movie->description:'',['style'=>'resize:none !important','class'=>'form-control','placeholder'=>'Nhập mô tả','id'=>'description']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('tags','Tag phim',[]); ?>

                        <?php echo Form::textarea('tags',isset($movie)? $movie->tags:'',['style'=>'resize:none !important','class'=>'form-control','placeholder'=>'Nhập tag']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('status','Status',[]); ?>

                        <?php echo Form::select('status', ['1'=>'Hiển thị','0'=>'Không'],isset($movie)? $movie->status:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('category','Category',[]); ?>

                        <?php echo Form::select('category_id', $category ,isset($movie)? $movie->category:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('country','Country',[]); ?>

                        <?php echo Form::select('country_id', $country,isset($movie)? $movie->country:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('genre','Genre',[]); ?>

                        <?php echo Form::select('genre_id', $genre ,isset($movie)? $movie->genre:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('phim_hot','Phim hot',[]); ?>

                        <?php echo Form::select('phim_hot', ['1'=>'Phim hot','0'=>'Không hot'] ,isset($movie)? $movie->phim_hot:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('resolution','Resolution',[]); ?>

                        <?php echo Form::select('resolution', ['0'=>'HD','1'=>'SD','2'=>'HDCam','3'=>'FullHD'] ,isset($movie)? $movie->resolution:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('phude','Phụ đề',[]); ?>

                        <?php echo Form::select('phude', ['0'=>'Phụ đề','1'=>'Thuyết minh'] ,isset($movie)? $movie->phude:'',['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('thoiluong','Thời lượng',[]); ?>

                        <?php echo Form::text('thoiluong',isset($movie)? $movie->thoiluong:'',['class'=>'form-control','placeholder'=>'Nhập vào thời lượng phim']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('sotap','Số tập',[]); ?>

                        <?php echo Form::text('sotap',isset($movie)? $movie->sotap:'',['class'=>'form-control','placeholder'=>'Nhập vào số tập phim']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('image','Image',[]); ?>

                        <?php echo Form::file('image',['class'=>'form-control']); ?>

                        <?php if(isset($movie)): ?>
                            <img width="20%" src="<?php echo e(asset('public/upload/movie/'.$movie->image)); ?>">
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <?php if(!isset($movie)): ?>
                            <?php echo Form::submit('Thêm dữ liệu!',['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                        <?php echo Form::submit('Cập nhật!',['class'=>'btn btn-success']); ?>

                        <?php endif; ?>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/movie/form.blade.php ENDPATH**/ ?>