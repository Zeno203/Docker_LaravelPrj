
<aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Phim hot</span>
                     </div>
                  </div>
                  <?php $__currentLoopData = $phimhot_sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot_sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                           <div class="item post-37176">
                              <a href="<?php echo e(route('movie',$hot_sidebar->slug)); ?>" title="<?php echo e($hot_sidebar->title); ?>">
                                 <div class="item-link">
                                    <?php if(isset($hot_sidebar->image) && !empty($hot_sidebar->image)): ?>
                                        <?php if(preg_match("/^http/", $hot_sidebar->image)): ?>
                                            <img src="<?php echo e($hot_sidebar->image); ?>" class="lazy post-thumb" alt="<?php echo e($hot_sidebar->title); ?>" title="<?php echo e($hot_sidebar->title); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('public/upload/movie/'.$hot_sidebar->image)); ?>" class="lazy post-thumb" alt="<?php echo e($hot_sidebar->title); ?>" title="<?php echo e($hot_sidebar->title); ?>">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('path_to_default_image.png')); ?>" class="lazy post-thumb" alt="default image" title="default image">
                                    <?php endif; ?>

                                    <span class="is_trailer">
                                        <?php if($hot_sidebar->resolution == 0): ?>
                                            HD
                                        <?php elseif($hot_sidebar->resolution == 1): ?>
                                            SD
                                        <?php elseif($hot_sidebar->resolution == 2): ?>
                                            HDCam
                                        <?php elseif($hot_sidebar->resolution == 3): ?>
                                            FullHD
                                        <?php endif; ?>
                                    </span>

                                 </div>
                                 <p class="title"><?php echo e($hot_sidebar->title); ?></p>
                              </a>
                              <div class="viewsCount" style="color: #9d9d9d;"><?php echo e($hot_sidebar->view); ?></div>
                              <div style="float: left;">
                                 <span class="user-rate-image post-large-rate stars-large-vang" style="display: block;/* width: 100%; */">
                                 <span style="width: 0%"></span>
                                 </span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="clearfix"></div>
               </div>
            </aside>
            <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Top Views</span>
                        <ul class="halim-popular-tab" role="tablist">
                           <!-- <li role="presentation" class="active">
                              <a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="10" data-type="today">Day</a>
                           </li>
                           <li role="presentation">
                              <a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="10" data-type="week">Week</a>
                           </li>
                           <li role="presentation">
                              <a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="10" data-type="month">Month</a>
                           </li> -->
                           <!-- <li role="presentation">
                              <a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="10" data-type="all">All</a>
                           </li> -->
                        </ul>
                     </div>
                  </div>
                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                        <?php $__currentLoopData = $topview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item post-37176">
                                <a href="<?php echo e(route('movie',$tview->slug)); ?>" title="<?php echo e($tview->title); ?>">
                                    <div class="item-link">
                                    <?php if(isset($tview->image) && !empty($tview->image)): ?>
                                        <?php if(preg_match("/^http/", $tview->image)): ?>
                                            <img src="<?php echo e($tview->image); ?>" class="lazy post-thumb" alt="<?php echo e($tview->title); ?>" title="<?php echo e($tview->title); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('public/upload/movie/'.$tview->image)); ?>" class="lazy post-thumb" alt="<?php echo e($tview->title); ?>" title="<?php echo e($tview->title); ?>">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('path_to_default_image.png')); ?>" class="lazy post-thumb" alt="default image" title="default image">
                                    <?php endif; ?>
                                    <span class="is_trailer">
                                        <?php if($tview->resolution == 0): ?>
                                            HD
                                        <?php elseif($tview->resolution == 1): ?>
                                                SD
                                        <?php elseif($tview->resolution == 2): ?>
                                                HDCam
                                        <?php elseif($tview->resolution == 3): ?>
                                                FullHD
                                        <?php endif; ?>
                                        </span>
                                    </div>
                                    <p class="title"><?php echo e($tview->title); ?></p>
                                </a>
                                <div class="viewsCount" style="color: #9d9d9d;">Lượt xem: <?php echo e($tview->view); ?></div>
                                <div style="float: left;">
                                    <span class="user-rate-image post-large-rate stars-large-vang" style="display: block;/* width: 100%; */">
                                    <span style="width: 0%"></span>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                     </div>
                  </section>
                  <div class="clearfix"></div>
               </div>
            </aside>

<?php /**PATH D:\webphim\WebMovie\resources\views/pages/include/sidebar.blade.php ENDPATH**/ ?>