 <?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<div class="container" style="margin-left:-40px;width:-webkit-fill-available"
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table table-dark table-responsive" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tên phim</th>
                        <th scope="col">Tên chính thức</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Loại phim</th>
                        <th scope="col">Image</th>
                        <th scope="col">Số tập</th>
                        <th scope="col">Độ phân giải</th>
                        <th scope="col">Loại phụ đề</th>
                        <th scope="col">Thể loại</th>
                        <!-- <th scope="col">Quốc gia</th> -->
                        <th scope="col">Thời lượng</th>
                        <th scope="col">Năm</th>
                        <th scope="col">Quản lý</th>


                    </tr>
                </thead>
                <tbody >
                    <?php $__currentLoopData = $resp_movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key); ?></th>
                        <td scope="row"><?php echo e($res['name']); ?></td>
                        <td scope="row"><?php echo e($res['origin_name']); ?></td>
                        <td scope="row"><?php echo e($res['slug']); ?></td>
                        <td scope="row">
                            <?php if($res['type'] === 'series'): ?>
                                Phim bộ
                            <?php else: ?>
                                Phim lẻ
                            <?php endif; ?>
                        </td>

                        <td>
                            <img width="100" height="100" src="<?php echo e($res['thumb_url']); ?>">
                        </td>
                        <td scope="row"><?php echo e($res['episode_total']); ?></td>
                        <td scope="row"><?php echo e($res['quality']); ?></td>
                        <td scope="row"><?php echo e($res['lang']); ?></td>
                        <td>
                            <?php $__currentLoopData = $res['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-info"><?php echo e($cate['name']); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td scope="row"><?php echo e($res['time']); ?></td>
                        <td scope="row"><?php echo e($res['year']); ?></td>
                        <td scope="row">
                            <a href="<?php echo e(route('leech-store',$res['slug'])); ?>" class="btn btn-success btn-xs" >Lưu phim </a>
                            <a href="<?php echo e(route('leech-episodeAdd',$res['slug'])); ?>" class="btn btn-success btn-xs" >Thêm phim API </a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/leech/detail.blade.php ENDPATH**/ ?>