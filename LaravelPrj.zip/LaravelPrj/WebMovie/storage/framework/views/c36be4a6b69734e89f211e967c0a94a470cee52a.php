 <?php $__env->startSection('content'); ?>
<div class="container" style="width:-webkit-fill-available">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <table class="table table-dark" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tên phim</th>
                        <th scope="col">Tập phim</th>
                        <th scope="col">Link phim</th>
                        <th scope="col">Trạng Thái</th>
                        <th scope="col">Manage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($ep->movie->title); ?></td>
                            <td><?php echo e($ep->episode); ?></td>
                            <td><?php echo e($ep->linkphim); ?></td>

                            <td>
                                <?php if($ep->movie->status == 1): ?>
                                    Hiển thị
                                <?php else: ?>
                                    Không hiển thị
                                <?php endif; ?>
                            </td>

                            <td>
                            <?php echo Form::open(['route' => ['episode.destroy',$ep->id],
                                            'method'=>'DELETE',
                                            'onsubmit'=>'return confirm("Ngon thì xóa đi?")'
                                            ]); ?>

                                        <?php echo Form::submit('Xóa!',['class'=>'btn btn-danger']); ?>

                            <?php echo Form::close(); ?>


                        <a href="<?php echo e(route('episode.edit',$ep->id)); ?>" class="btn btn-warning">Sửa</a>

                        </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/episode/index.blade.php ENDPATH**/ ?>