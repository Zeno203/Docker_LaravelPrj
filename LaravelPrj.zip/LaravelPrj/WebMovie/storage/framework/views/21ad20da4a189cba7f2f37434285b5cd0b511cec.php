 <?php $__env->startSection('content'); ?>
<div class="container" style="width:-webkit-fill-available">
    <div class="row justify-content-center">

    <div class="col-md-12"
            <div class="card">
                <div class="card-header">Quản lý tập phim</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(!isset($episode)): ?>
                    <?php echo Form::open(['route' => 'episode.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => ['episode.update',$movie->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>

                    <div class="form-group">
                        <?php echo Form::label('movie_title','Phim',[]); ?>

                        <?php echo Form::text('movie_title' ,isset($movie)? $movie->title:'',['class'=>'form-control','readonly']); ?>

                        <?php echo Form::hidden('movie_id' ,isset($movie)? $movie->id:''); ?>


                    </div>
                    <div class="form-group">
                        <?php echo Form::label('linkphim','Nhập link phim',[]); ?>

                        <?php echo Form::text('linkphim' ,isset($episode)? $episode->linkphim:'',['class'=>'form-control']); ?>

                    </div>


                    <div class="form-group">
                        <?php echo Form::label('episode','Tập phim',[]); ?>

                        <?php echo Form::text('episode' ,isset($episode)? $episode->episode:'',['class'=>'form-control', 'id'=>'show_movie']); ?>


                        <!-- <?php echo Form::label('episode','Chọn tập phim',[]); ?>

                        <select name="episode" class="form-control" id="show_movie">

                        </select> -->
                    </div>



                    <div class="form-group">
                        <?php if(!isset($episode)): ?>
                            <?php echo Form::submit('Thêm tập phim!',['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                        <?php echo Form::submit('Cập nhật tập phim!',['class'=>'btn btn-success']); ?>

                        <?php endif; ?>
                    </div>
                    <?php echo Form::close(); ?>


                </div>

            </div>

        </div>

        ---------------Link phim-----------
        <div class="col-md-12">
            <table class="table table-dark" id="myTable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tên phim</th>
                        <th scope="col">Tập phim</th>
                        <th scope="col">Link phim</th>
                        <th scope="col">Trạng Thái</th>
                        <th scope="col">Manage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($ep->movie->title); ?></td>
                            <td><?php echo e($ep->episode); ?></td>
                            <td><?php echo e($ep->linkphim); ?></td>

                            <td>
                                <?php if($ep->movie->status == 1): ?>
                                    Hiển thị
                                <?php else: ?>
                                    Không hiển thị
                                <?php endif; ?>
                            </td>

                            <td>
                            <?php echo Form::open(['route' => ['episode.destroy',$ep->id],
                                            'method'=>'DELETE',
                                            'onsubmit'=>'return confirm("Ngon thì xóa đi?")'
                                            ]); ?>

                                        <?php echo Form::submit('Xóa!',['class'=>'btn btn-danger']); ?>

                            <?php echo Form::close(); ?>

                        <a href="<?php echo e(route('episode.edit',$ep->id)); ?>" class="btn btn-warning">Sửa</a>

                        </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webphim\WebMovie\resources\views/admin/episode/add_episode.blade.php ENDPATH**/ ?>